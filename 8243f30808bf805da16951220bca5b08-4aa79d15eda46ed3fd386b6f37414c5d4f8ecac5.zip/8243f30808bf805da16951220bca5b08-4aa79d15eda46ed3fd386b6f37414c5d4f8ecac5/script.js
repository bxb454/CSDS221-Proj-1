toastr.options = {
      "closeButton": true,
      "debug": false,
      "newestOnTop": false,
      "progressBar": false,
      "positionClass": "toast-top-center",
      "preventDuplicates": false,
      "onclick": null,
      "showDuration": "500",
      "hideDuration": "1000",
      "timeOut": "5000",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }


$(document).ready(function($) {
  $('#reset-button').click(function() {
    $('#booking-form')[0].reset();
    toastr.info('Form has been reset.');
    //$(this).removeClass('has-error');
  });
  
   $(document).ready(function() {
    $('#booking-form').submit(function(event) {
      // Prevent the form from submitting normally
      event.preventDefault();

      // Perform validation
      let valid = true;

      // Validate username
      let username = $('#uname').val();
      if (username === '') {
        toastr.error('Please enter a username');
        $('#uname').addClass('has-error');
        valid = false;
      }
      else {
        $('#uname').removeClass('has-error');
      }

      // Validate first name
      let firstName = $('#fname').val();
      if (firstName === '') {
        toastr.error('Please enter your first name');
        $('#fname').addClass('has-error');
        valid = false;
      }
       else {
        $('#uname').removeClass('has-error');
      }

      // Validate last name
      let lastName = $('#lname').val();
      if (lastName === '') {
        toastr.error('Please enter your last name');
        $('#lname').addClass('has-error');
        valid = false;
      }
       else {
        $('#lname').removeClass('has-error');
      }

      // Validate email
      let email = $('#email-input').val();
      if (email === '') {
        toastr.error('Please enter an email address');
        $('#emailinput').addClass('has-error');
        valid = false;
      } else if (!isValidEmail(email)) {
        toastr.error('Please enter a valid email address');
         $('#emailinput').addClass('has-error');
        valid = false;
      }
       else {
        $('#emailinput').removeClass('has-error');
      }

      // Validate fax
      let fax = $('#faxinput').val();
      if (fax === '') {
        toastr.error('Please enter a valid fax number.');
        valid = false;
        $('faxinput').addClass('has-error');
      }
       else {
        $('#faxinput').removeClass('has-error');
      }
      
      // Validate phone #
      let phone = $('#phoneinput').val();
      if (phone === '') {
        toastr.error('Please enter a valid phone number.');
        valid = false;
        $('phoneinput').addClass('has-error');
      }
       else {
        $('#phoneinput').removeClass('has-error');
      }

      calculateTotalDays();
      calculateTotalCost();
      
      //Validate cost and days and that they are correct
      if(calculateTotalDays() < 0 || isNaN(calculateTotalDays())) {
        toastr.error('There is a negative date difference.');
        valid = false;
        $('#days-amount').addClass('has-error');
      }
       else {
        $('#days-amount').removeClass('has-error');
      }
      if(calculateTotalCost() < 0 || isNaN(calculateTotalCost())) {
        toastr.error('There is a negative cost.');
        valid = false;
        $('#cost').addClass('has-error');
      }
       else {
        $('#cost').removeClass('has-error');
      }
      
      // If the form is valid, submit it
      if (valid) {
        // Display success message
        toastr.success('Form submitted successfully!');
      }
    });
  });

  function isValidEmail(email) {
    // Basic email validation using regex
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
  }
  
  function calculateTotalCost() {
    let numAdults = $('#num-adults').prop('value');
    let totalCost = Math.floor(150 * numAdults *             calculateTotalDays());
    $('#cost').prop('value', '$'+totalCost);
    return totalCost;
  }
  
  function calculateTotalDays() {
    let startDate = moment($('#datepicker-checkin').datepicker("getDate"));
 let endDate = moment($('#datepicker-checkout').datepicker("getDate"));
    let totalDays = Math.floor(moment.duration(startDate.diff(endDate)).asDays());
    $('#days-amount').prop('value', totalDays);
    return totalDays;
  }
});